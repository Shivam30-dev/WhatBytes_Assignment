"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/components/assets/profile-image.jpeg":
/*!**************************************************!*\
  !*** ./src/components/assets/profile-image.jpeg ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\"src\":\"/_next/static/media/profile-image.fc0a27e1.jpeg\",\"height\":3796,\"width\":3004,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fprofile-image.fc0a27e1.jpeg&w=6&q=70\",\"blurWidth\":6,\"blurHeight\":8});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9hc3NldHMvcHJvZmlsZS1pbWFnZS5qcGVnIiwibWFwcGluZ3MiOiI7QUFBQSwrREFBZSxDQUFDLGtOQUFrTiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9zcmMvY29tcG9uZW50cy9hc3NldHMvcHJvZmlsZS1pbWFnZS5qcGVnP2I1ZTciXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL21lZGlhL3Byb2ZpbGUtaW1hZ2UuZmMwYTI3ZTEuanBlZ1wiLFwiaGVpZ2h0XCI6Mzc5NixcIndpZHRoXCI6MzAwNCxcImJsdXJEYXRhVVJMXCI6XCIvX25leHQvaW1hZ2U/dXJsPSUyRl9uZXh0JTJGc3RhdGljJTJGbWVkaWElMkZwcm9maWxlLWltYWdlLmZjMGEyN2UxLmpwZWcmdz02JnE9NzBcIixcImJsdXJXaWR0aFwiOjYsXCJibHVySGVpZ2h0XCI6OH07Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/assets/profile-image.jpeg\n"));

/***/ })

});